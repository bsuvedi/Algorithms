
public class ArrayStructures {

	private int[] theArray = new int[50];
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
